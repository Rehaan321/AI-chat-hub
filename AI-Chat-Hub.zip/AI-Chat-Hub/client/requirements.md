## Packages
react-markdown | For rendering AI chat responses with markdown support
remark-gfm | GitHub Flavored Markdown support for react-markdown
date-fns | Date formatting for chat timestamps
framer-motion | For smooth animations and page transitions

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["Inter", "sans-serif"],
  display: ["Space Grotesk", "sans-serif"],
}
