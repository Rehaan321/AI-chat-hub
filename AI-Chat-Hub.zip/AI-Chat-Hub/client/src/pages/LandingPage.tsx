import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Cpu, Zap, Shield, Sparkles } from "lucide-react";
import { useLocation } from "wouter";

export default function LandingPage() {
  const { isLoading } = useAuth();
  const [_, setLocation] = useLocation();

  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col overflow-hidden relative selection:bg-primary/30">
      
      {/* Background Ambience */}
      <div className="absolute top-[-20%] left-[-10%] w-[600px] h-[600px] bg-primary/20 rounded-full blur-[120px] opacity-50 animate-pulse" />
      <div className="absolute bottom-[-10%] right-[-5%] w-[500px] h-[500px] bg-purple-600/10 rounded-full blur-[100px] opacity-30" />

      {/* Navbar */}
      <nav className="relative z-10 px-6 py-6 flex justify-between items-center max-w-7xl mx-auto w-full">
        <div className="flex items-center gap-2">
          <div className="size-9 rounded-lg bg-gradient-to-br from-primary to-purple-600 flex items-center justify-center shadow-lg shadow-primary/20">
            <Cpu className="text-white size-5" />
          </div>
          <span className="font-display font-bold text-xl tracking-tight">Nexus AI</span>
        </div>
        <div className="flex gap-4">
          <Button 
            onClick={handleLogin} 
            className="rounded-full px-6 font-medium shadow-lg shadow-primary/25 hover:shadow-primary/40 transition-all hover:-translate-y-0.5"
          >
            Sign In
          </Button>
        </div>
      </nav>

      {/* Hero Section */}
      <main className="flex-1 flex flex-col justify-center items-center px-4 relative z-10">
        <div className="text-center max-w-4xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-8 duration-700">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-secondary/50 border border-white/5 text-xs font-medium text-primary mb-4 backdrop-blur-sm">
            <Sparkles className="size-3" />
            <span>Next Generation Intelligence</span>
          </div>
          
          <h1 className="text-5xl md:text-7xl font-display font-bold tracking-tighter leading-[1.1]">
            Unlock the power of <br/>
            <span className="text-gradient">Artificial Intelligence</span>
          </h1>
          
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            Experience conversations that feel human. Nexus AI helps you write, code, and reason with unprecedented capabilities.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
            <Button 
              size="lg" 
              onClick={handleLogin}
              className="text-lg px-8 h-14 rounded-full bg-white text-black hover:bg-white/90 shadow-xl hover:scale-105 transition-all duration-300"
            >
              Get Started Free
            </Button>
            <Button 
              size="lg" 
              variant="outline"
              onClick={handleLogin}
              className="text-lg px-8 h-14 rounded-full border-white/10 hover:bg-white/5 backdrop-blur-sm transition-all duration-300"
            >
              View Demo
            </Button>
          </div>
        </div>

        {/* Feature Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-6xl mx-auto mt-24 w-full px-4">
          <FeatureCard 
            icon={<Zap className="size-6 text-yellow-400" />}
            title="Real-time Responses"
            description="Experience lightning fast streaming responses that feel like a natural conversation."
          />
          <FeatureCard 
            icon={<Cpu className="size-6 text-primary" />}
            title="Advanced Reasoning"
            description="Capable of complex problem solving, coding, and creative writing tasks."
          />
          <FeatureCard 
            icon={<Shield className="size-6 text-green-400" />}
            title="Secure & Private"
            description="Your conversations are encrypted and stored securely. Privacy first design."
          />
        </div>
      </main>

      {/* Footer */}
      <footer className="relative z-10 py-8 text-center text-muted-foreground text-sm border-t border-white/5 mt-20">
        <p>&copy; {new Date().getFullYear()} Nexus AI. All rights reserved.</p>
      </footer>
    </div>
  );
}

function FeatureCard({ icon, title, description }: { icon: React.ReactNode, title: string, description: string }) {
  return (
    <div className="glass-panel p-6 rounded-2xl hover:border-primary/30 transition-colors duration-300 group">
      <div className="size-12 rounded-xl bg-secondary/50 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300 border border-white/5">
        {icon}
      </div>
      <h3 className="text-xl font-bold mb-2 font-display">{title}</h3>
      <p className="text-muted-foreground leading-relaxed">{description}</p>
    </div>
  );
}
