import { Sidebar } from "@/components/Sidebar";
import { ChatInterface } from "@/components/ChatInterface";
import { useRoute } from "wouter";
import { Cpu, Menu } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";

export default function Home() {
  const [match, params] = useRoute("/chat/:id");
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const { user } = useAuth();

  // If we have an ID, show that chat. Otherwise show empty state.
  const conversationId = match && params?.id ? parseInt(params.id) : null;

  return (
    <div className="flex h-screen overflow-hidden bg-background text-foreground">
      {/* Desktop Sidebar */}
      <Sidebar className="hidden md:flex border-r border-border/50" />

      {/* Mobile Sidebar (Sheet) */}
      <div className="md:hidden fixed top-4 left-4 z-50">
        <Sheet open={isMobileOpen} onOpenChange={setIsMobileOpen}>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" className="rounded-lg bg-secondary/80 backdrop-blur-md border border-white/10">
              <Menu className="size-5" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="p-0 border-r border-white/10 w-80 bg-card">
            <Sidebar className="w-full h-full border-none" />
          </SheetContent>
        </Sheet>
      </div>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col relative min-w-0">
        {conversationId ? (
          <ChatInterface key={conversationId} conversationId={conversationId} />
        ) : (
          <EmptyState firstName={user?.firstName} />
        )}
      </main>
    </div>
  );
}

function EmptyState({ firstName }: { firstName?: string | null }) {
  return (
    <div className="flex-1 flex flex-col items-center justify-center p-8 text-center relative overflow-hidden">
      {/* Decorative Background */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-primary/10 via-background to-background" />
      
      <div className="relative z-10 max-w-2xl animate-in fade-in zoom-in-95 duration-500">
        <div className="size-24 rounded-3xl bg-gradient-to-br from-primary to-purple-600 flex items-center justify-center mx-auto mb-8 shadow-2xl shadow-primary/30">
          <Cpu className="size-12 text-white" />
        </div>
        
        <h1 className="text-4xl md:text-5xl font-display font-bold mb-6 tracking-tight">
          Welcome back{firstName ? `, ${firstName}` : ""}
        </h1>
        
        <p className="text-xl text-muted-foreground mb-8 leading-relaxed">
          Nexus AI is ready to assist you. Select a conversation from the sidebar or start a new chat to begin.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-lg mx-auto">
          <div className="p-4 rounded-xl bg-secondary/30 border border-white/5 hover:bg-secondary/50 transition-colors text-left">
            <h3 className="font-semibold mb-1 text-foreground">Creative Writing</h3>
            <p className="text-sm text-muted-foreground">Draft stories, emails, and essays with ease.</p>
          </div>
          <div className="p-4 rounded-xl bg-secondary/30 border border-white/5 hover:bg-secondary/50 transition-colors text-left">
            <h3 className="font-semibold mb-1 text-foreground">Code Assistant</h3>
            <p className="text-sm text-muted-foreground">Debug code, write functions, and learn new frameworks.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
