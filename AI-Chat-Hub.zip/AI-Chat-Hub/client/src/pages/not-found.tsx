import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { AlertTriangle } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-background text-foreground">
      <div className="text-center space-y-6 animate-in fade-in zoom-in-95 duration-300">
        <div className="flex justify-center">
          <div className="size-20 rounded-2xl bg-destructive/10 flex items-center justify-center text-destructive">
            <AlertTriangle className="size-10" />
          </div>
        </div>
        
        <h1 className="text-4xl font-display font-bold tracking-tight">Page Not Found</h1>
        <p className="text-muted-foreground max-w-md mx-auto">
          The page you are looking for doesn't exist or has been moved.
        </p>

        <Link href="/">
          <Button size="lg" className="rounded-full px-8">
            Return Home
          </Button>
        </Link>
      </div>
    </div>
  );
}
