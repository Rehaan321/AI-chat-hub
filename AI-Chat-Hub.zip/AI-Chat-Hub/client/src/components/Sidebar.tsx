import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useConversations, useCreateConversation, useDeleteConversation } from "@/hooks/use-chat";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  MessageSquarePlus, 
  LogOut, 
  MessageSquare, 
  Trash2, 
  Loader2,
  Cpu
} from "lucide-react";
import { cn } from "@/lib/utils";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export function Sidebar({ className }: { className?: string }) {
  const [location, setLocation] = useLocation();
  const { user, logout } = useAuth();
  const { data: conversations, isLoading } = useConversations();
  const createMutation = useCreateConversation();
  const deleteMutation = useDeleteConversation();

  const handleNewChat = () => {
    createMutation.mutate("New Chat", {
      onSuccess: (newConv) => {
        setLocation(`/chat/${newConv.id}`);
      }
    });
  };

  const handleDelete = (e: React.MouseEvent, id: number) => {
    e.preventDefault();
    e.stopPropagation();
    deleteMutation.mutate(id, {
      onSuccess: () => {
        if (location === `/chat/${id}`) {
          setLocation("/");
        }
      }
    });
  };

  return (
    <div className={cn("flex flex-col h-screen bg-card border-r border-border/40 w-80 shrink-0", className)}>
      {/* Header */}
      <div className="p-4 border-b border-border/40">
        <div className="flex items-center gap-2 mb-6 px-2">
          <div className="size-8 rounded-lg bg-gradient-to-br from-primary to-purple-600 flex items-center justify-center shadow-lg shadow-primary/20">
            <Cpu className="text-white size-5" />
          </div>
          <span className="font-display font-bold text-xl tracking-tight">Nexus AI</span>
        </div>
        
        <Button 
          onClick={handleNewChat} 
          className="w-full justify-start gap-2 bg-primary/10 text-primary hover:bg-primary/20 border border-primary/20 shadow-none h-11"
        >
          {createMutation.isPending ? <Loader2 className="size-4 animate-spin" /> : <MessageSquarePlus className="size-4" />}
          New Chat
        </Button>
      </div>

      {/* Conversation List */}
      <ScrollArea className="flex-1 px-3 py-4">
        <div className="space-y-1">
          {isLoading ? (
            <div className="flex flex-col gap-2 p-2">
              {[1, 2, 3].map(i => (
                <div key={i} className="h-10 bg-secondary/50 rounded-lg animate-pulse" />
              ))}
            </div>
          ) : conversations?.length === 0 ? (
            <div className="text-center py-10 px-4 text-muted-foreground text-sm">
              <p>No conversations yet.</p>
              <p>Start a new chat to begin.</p>
            </div>
          ) : (
            conversations?.map((conv) => (
              <div key={conv.id} className="group relative">
                <Link href={`/chat/${conv.id}`}>
                  <div className={cn(
                    "flex items-center gap-3 px-3 py-3 rounded-xl transition-all duration-200 cursor-pointer text-sm font-medium",
                    location === `/chat/${conv.id}` 
                      ? "bg-secondary text-foreground shadow-sm ring-1 ring-white/5" 
                      : "text-muted-foreground hover:bg-secondary/50 hover:text-foreground"
                  )}>
                    <MessageSquare className="size-4 shrink-0 opacity-70" />
                    <span className="truncate pr-8">{conv.title || "New Conversation"}</span>
                  </div>
                </Link>
                
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <button 
                      className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 rounded-md text-muted-foreground opacity-0 group-hover:opacity-100 hover:bg-destructive/20 hover:text-destructive transition-all"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <Trash2 className="size-3.5" />
                    </button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Delete conversation?</AlertDialogTitle>
                      <AlertDialogDescription>
                        This will permanently delete this chat history. This action cannot be undone.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction 
                        onClick={(e) => handleDelete(e, conv.id)}
                        className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                      >
                        Delete
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            ))
          )}
        </div>
      </ScrollArea>

      {/* Footer */}
      <div className="p-4 border-t border-border/40 bg-card/50">
        <div className="flex items-center gap-3 p-2 rounded-xl bg-secondary/30 border border-white/5">
          <div className="size-9 rounded-full bg-gradient-to-tr from-blue-500 to-cyan-400 flex items-center justify-center text-white font-bold shadow-inner">
            {user?.firstName?.[0] || user?.email?.[0] || "U"}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium truncate">{user?.firstName || "User"}</p>
            <p className="text-xs text-muted-foreground truncate">{user?.email}</p>
          </div>
          <Button 
            variant="ghost" 
            size="icon" 
            className="text-muted-foreground hover:text-foreground shrink-0"
            onClick={() => logout()}
          >
            <LogOut className="size-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
