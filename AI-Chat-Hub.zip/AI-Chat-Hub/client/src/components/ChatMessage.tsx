import { cn } from "@/lib/utils";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { Cpu, User } from "lucide-react";
import { motion } from "framer-motion";

interface ChatMessageProps {
  role: "user" | "assistant";
  content: string;
  isStreaming?: boolean;
}

export function ChatMessage({ role, content, isStreaming }: ChatMessageProps) {
  const isUser = role === "user";

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, ease: "easeOut" }}
      className={cn(
        "flex w-full gap-4 py-8 px-4 md:px-8",
        isUser ? "bg-transparent" : "bg-secondary/20 border-y border-white/5"
      )}
    >
      <div className="max-w-3xl mx-auto flex gap-4 w-full">
        {/* Avatar */}
        <div className={cn(
          "size-8 md:size-10 rounded-xl flex items-center justify-center shrink-0 shadow-lg mt-0.5",
          isUser 
            ? "bg-gradient-to-br from-blue-500 to-cyan-500 text-white" 
            : "bg-gradient-to-br from-primary to-purple-600 text-white"
        )}>
          {isUser ? <User className="size-5 md:size-6" /> : <Cpu className="size-5 md:size-6" />}
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0 space-y-1">
          <div className="font-semibold text-sm text-foreground/80 mb-1">
            {isUser ? "You" : "Nexus AI"}
          </div>
          
          <div className={cn(
            "prose prose-invert max-w-none text-base md:text-[15px] leading-relaxed",
            isUser ? "text-foreground/90" : "text-foreground/90"
          )}>
            <ReactMarkdown 
              remarkPlugins={[remarkGfm]}
              components={{
                // Style links to open in new tab
                a: ({ node, ...props }) => (
                  <a target="_blank" rel="noopener noreferrer" className="text-primary hover:underline" {...props} />
                ),
              }}
            >
              {content}
            </ReactMarkdown>
            
            {isStreaming && (
              <span className="inline-block w-1.5 h-4 ml-1 align-middle bg-primary animate-pulse rounded-full" />
            )}
          </div>
        </div>
      </div>
    </motion.div>
  );
}
