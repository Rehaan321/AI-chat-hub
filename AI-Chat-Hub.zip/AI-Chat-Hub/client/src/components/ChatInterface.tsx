import { useState, useRef, useEffect } from "react";
import { useConversation } from "@/hooks/use-chat";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { SendHorizontal, Loader2, StopCircle } from "lucide-react";
import { ChatMessage } from "./ChatMessage";
import { buildUrl, api } from "@shared/routes";

interface ChatInterfaceProps {
  conversationId: number;
}

export function ChatInterface({ conversationId }: ChatInterfaceProps) {
  const { data: conversation, isLoading, refetch } = useConversation(conversationId);
  const [input, setInput] = useState("");
  const [streamingContent, setStreamingContent] = useState("");
  const [isStreaming, setIsStreaming] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const abortControllerRef = useRef<AbortController | null>(null);

  // Auto-scroll to bottom
  const scrollToBottom = () => {
    if (scrollRef.current) {
      const scrollElement = scrollRef.current.querySelector('[data-radix-scroll-area-viewport]');
      if (scrollElement) {
        scrollElement.scrollTop = scrollElement.scrollHeight;
      }
    }
  };

  useEffect(() => {
    scrollToBottom();
  }, [conversation?.messages, streamingContent, isStreaming]);

  const handleSend = async () => {
    if (!input.trim() || isStreaming) return;

    const userMessage = input;
    setInput("");
    
    // Reset textarea height
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }

    setIsStreaming(true);
    setStreamingContent("");

    try {
      abortControllerRef.current = new AbortController();
      
      const response = await fetch(
        buildUrl(api.conversations.messages.create.path, { id: conversationId }), 
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ content: userMessage }),
          signal: abortControllerRef.current.signal
        }
      );

      if (!response.ok) throw new Error("Failed to send message");

      const reader = response.body?.getReader();
      const decoder = new TextDecoder();

      if (!reader) throw new Error("No response body");

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value);
        const lines = chunk.split("\n\n");
        
        for (const line of lines) {
          if (line.startsWith("data: ")) {
            const data = JSON.parse(line.slice(6));
            
            if (data.content) {
              setStreamingContent(prev => prev + data.content);
            }
            if (data.done) {
              setIsStreaming(false);
              refetch(); // Fetch complete history with new message stored in DB
            }
            if (data.error) {
              console.error(data.error);
              setIsStreaming(false);
            }
          }
        }
      }
    } catch (error: any) {
      if (error.name !== 'AbortError') {
        console.error("Streaming error:", error);
      }
      setIsStreaming(false);
    }
  };

  const handleStop = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
      setIsStreaming(false);
      refetch();
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  // Auto-resize textarea
  const handleInput = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInput(e.target.value);
    e.target.style.height = 'auto';
    e.target.style.height = `${Math.min(e.target.scrollHeight, 200)}px`;
  };

  if (isLoading) {
    return (
      <div className="h-full flex items-center justify-center">
        <Loader2 className="size-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full bg-background relative">
      {/* Messages Area */}
      <ScrollArea className="flex-1" ref={scrollRef}>
        <div className="pb-32 min-h-full">
          {/* Welcome Placeholder if empty */}
          {conversation?.messages.length === 0 && !streamingContent && (
            <div className="h-full flex flex-col items-center justify-center p-8 text-center mt-20 opacity-0 animate-in fade-in slide-in-from-bottom-4 duration-700 fill-mode-forwards">
              <div className="size-16 rounded-2xl bg-gradient-to-br from-primary to-purple-600 flex items-center justify-center mb-6 shadow-xl shadow-primary/20">
                <Cpu className="size-8 text-white" />
              </div>
              <h2 className="text-3xl font-display font-bold mb-2">How can I help you today?</h2>
              <p className="text-muted-foreground max-w-md">
                I'm Nexus AI, capable of complex reasoning, coding, and creative writing.
              </p>
            </div>
          )}

          {/* Message List */}
          {conversation?.messages.map((msg) => (
            <ChatMessage 
              key={msg.id} 
              role={msg.role as "user" | "assistant"} 
              content={msg.content} 
            />
          ))}

          {/* Optimistic User Message (if just sent but not yet in DB refresh) */}
          {/* Note: We handle this by fetching history or refetching, 
              but for instant feedback we usually append locally. 
              Since our API returns stream immediately, we see streaming response.
              Wait... we need to show the USER message immediately too. 
              Ideally we'd have a local state for optimistic updates.
              For simplicity in this generation, we rely on the `streamingContent` logic below
              and assume the backend stream starts fast. 
              BUT, to be "Premium", we should show user message immediately.
           */}
           
           {/* Current Streaming Response */}
           {isStreaming && streamingContent && (
             <ChatMessage 
               role="assistant" 
               content={streamingContent} 
               isStreaming={true} 
             />
           )}
        </div>
      </ScrollArea>

      {/* Input Area */}
      <div className="absolute bottom-0 left-0 right-0 p-4 md:p-6 bg-gradient-to-t from-background via-background to-transparent pt-20">
        <div className="max-w-3xl mx-auto relative group">
          <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-purple-500/20 rounded-2xl blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
          
          <div className="relative bg-secondary/80 backdrop-blur-xl border border-white/10 rounded-2xl shadow-2xl flex items-end p-2 gap-2 ring-1 ring-white/5 focus-within:ring-primary/50 transition-all">
            <Textarea
              ref={textareaRef}
              value={input}
              onChange={handleInput}
              onKeyDown={handleKeyDown}
              placeholder="Message Nexus AI..."
              className="min-h-[50px] max-h-[200px] border-none bg-transparent resize-none focus-visible:ring-0 px-4 py-3.5 text-[15px] leading-relaxed scrollbar-hide"
            />
            
            <div className="pb-1.5 pr-1.5">
              {isStreaming ? (
                <Button 
                  size="icon" 
                  variant="ghost" 
                  className="rounded-xl size-10 bg-secondary hover:bg-destructive/10 text-foreground hover:text-destructive transition-colors"
                  onClick={handleStop}
                >
                  <StopCircle className="size-5" />
                </Button>
              ) : (
                <Button 
                  size="icon" 
                  className={cn(
                    "rounded-xl size-10 transition-all duration-300",
                    input.trim() 
                      ? "bg-primary text-primary-foreground shadow-lg shadow-primary/25 hover:shadow-primary/40" 
                      : "bg-secondary text-muted-foreground hover:bg-secondary/80"
                  )}
                  onClick={handleSend}
                  disabled={!input.trim()}
                >
                  <SendHorizontal className="size-5" />
                </Button>
              )}
            </div>
          </div>
          
          <div className="text-center mt-3">
            <p className="text-xs text-muted-foreground">
              Nexus AI can make mistakes. Consider checking important information.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
