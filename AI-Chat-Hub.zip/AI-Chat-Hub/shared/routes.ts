import { z } from "zod";
import { insertConversationSchema, insertMessageSchema, conversations, messages } from "./schema";

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
  unauthorized: z.object({
    message: z.string(),
  }),
};

export const api = {
  auth: {
    user: {
      method: "GET" as const,
      path: "/api/auth/user",
      responses: {
        200: z.object({
          id: z.string(),
          email: z.string().nullable(),
          firstName: z.string().nullable(),
          lastName: z.string().nullable(),
          profileImageUrl: z.string().nullable(),
        }),
        401: errorSchemas.unauthorized,
      },
    },
    login: {
      method: "GET" as const,
      path: "/api/login",
      responses: {},
    },
    logout: {
      method: "GET" as const,
      path: "/api/logout",
      responses: {},
    },
  },
  conversations: {
    list: {
      method: "GET" as const,
      path: "/api/conversations",
      responses: {
        200: z.array(z.custom<typeof conversations.$inferSelect>()),
      },
    },
    create: {
      method: "POST" as const,
      path: "/api/conversations",
      input: z.object({ title: z.string().optional() }),
      responses: {
        201: z.custom<typeof conversations.$inferSelect>(),
      },
    },
    get: {
      method: "GET" as const,
      path: "/api/conversations/:id",
      responses: {
        200: z.custom<typeof conversations.$inferSelect & { messages: typeof messages.$inferSelect[] }>(),
        404: errorSchemas.notFound,
      },
    },
    delete: {
      method: "DELETE" as const,
      path: "/api/conversations/:id",
      responses: {
        204: z.void(),
      },
    },
    messages: {
      create: {
        method: "POST" as const,
        path: "/api/conversations/:id/messages",
        input: z.object({ content: z.string() }),
        responses: {
          // Streaming response - handled specially by frontend
          200: z.void(),
        },
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}

export type Conversation = z.infer<typeof api.conversations.list.responses[200]>[number];
export type Message = typeof messages.$inferSelect;
