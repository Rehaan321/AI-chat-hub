import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth, registerAuthRoutes } from "./replit_integrations/auth";
import { registerChatRoutes } from "./replit_integrations/chat";
import { chatStorage } from "./replit_integrations/chat/storage";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Setup Authentication first
  await setupAuth(app);
  
  // Register Integration Routes
  registerAuthRoutes(app);
  registerChatRoutes(app);

  // Fallback for API 404s
  app.use("/api", (req, res) => {
    res.status(404).json({ message: "Not Found" });
  });

  // Seed Data
  try {
    const conversations = await chatStorage.getAllConversations();
    if (conversations.length === 0) {
      console.log("Seeding database...");
      const chat = await chatStorage.createConversation("Welcome to AI Chat");
      await chatStorage.createMessage(chat.id, "assistant", "# Welcome to your new AI Chat!\n\nI can help you with:\n- Writing code\n- Answering questions\n- Creative writing\n\nHow can I help you today?");
    }
  } catch (error) {
    console.error("Failed to seed database:", error);
    // Continue starting server even if seed fails
  }

  return httpServer;
}
